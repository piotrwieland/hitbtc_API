# IO.Swagger.Model.Trade
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** |  | 
**ClientOrderId** | **string** |  | 
**OrderId** | **long?** |  | 
**Symbol** | **string** |  | 
**Side** | **string** |  | 
**Quantity** | **string** |  | [optional] 
**Fee** | **string** |  | [optional] 
**Price** | **string** |  | [optional] 
**Timestamp** | **DateTime?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

