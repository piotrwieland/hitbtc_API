# IO.Swagger.Model.Candle
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Timestamp** | **DateTime?** |  | 
**Open** | **string** |  | 
**Close** | **string** |  | 
**Min** | **string** |  | 
**Max** | **string** |  | 
**Volume** | **string** |  | 
**VolumeQuote** | **string** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

