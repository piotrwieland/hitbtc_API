# IO.Swagger.Model.Error
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_Error** | [**ErrorError**](ErrorError.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

