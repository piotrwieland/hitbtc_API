# IO.Swagger.Model.OrderTradesReport
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **long?** |  | 
**Quantity** | **string** |  | [optional] 
**Price** | **string** |  | [optional] 
**Fee** | **string** |  | [optional] 
**Timestamp** | **DateTime?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

