# IO.Swagger.Model.PublicTrade
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int?** |  | [optional] 
**Price** | **string** |  | [optional] 
**Quantity** | **string** |  | [optional] 
**Side** | **string** |  | [optional] 
**Timestamp** | **DateTime?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

