# IO.Swagger.Model.Balance
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Currency** | **string** |  | [optional] 
**Available** | **string** | Amount available to spend | [optional] 
**Reserved** | **string** | Amount reserved on orders or payout | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

