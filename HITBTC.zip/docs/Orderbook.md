# IO.Swagger.Model.Orderbook
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ask** | [**List&lt;OrderbookAsk&gt;**](OrderbookAsk.md) |  | [optional] 
**Bid** | [**List&lt;OrderbookAsk&gt;**](OrderbookAsk.md) |  | [optional] 
**Timestamp** | **DateTime?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

